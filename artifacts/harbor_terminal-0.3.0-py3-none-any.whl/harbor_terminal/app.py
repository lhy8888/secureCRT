"""Harbor desktop shell. Terminal state and connection ownership live in modules."""
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QStandardPaths, Slot
from PySide6.QtGui import QColor, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLineEdit, QComboBox, QPushButton, QLabel, QTabWidget,
    QMessageBox, QInputDialog, QDialog, QDialogButtonBox, QFormLayout,
    QGroupBox, QFileDialog, QDockWidget, QTreeWidget, QTreeWidgetItem)

from . import profiles
from .session import Worker, PortProbe
from .terminal import Terminal
from .terminal_model import ENCODINGS
from .serial_config import SerialSettings
from .panels import SFTPDialog, LogDialog, HexDialog

DEFAULTS = dict(bytesize='8', parity='N', stopbits='1', flow_control='none',
                encoding='utf-8', backspace='del', private_key='')
STATES = dict(Connecting='连接中', Connected='已连接', Closing='关闭中', Disconnected='已断开')


class ConnectionOptions(QDialog):
    def __init__(self, options, parent=None):
        super().__init__(parent)
        self.setWindowTitle('连接与终端设置')
        self.resize(580, 380)
        layout = QVBoxLayout(self)
        terminal = QGroupBox('终端')
        form = QFormLayout(terminal)
        self.encoding = QComboBox(); self.encoding.addItems(ENCODINGS)
        self.encoding.setCurrentText(options['encoding'])
        self.backspace = QComboBox(); self.backspace.addItems(['del', 'bs'])
        self.backspace.setCurrentText(options['backspace'])
        form.addRow('字符编码', self.encoding); form.addRow('Backspace 发送', self.backspace)
        layout.addWidget(terminal)
        serial = QGroupBox('串口（波特率在主窗口设置）')
        form = QFormLayout(serial)
        self.serial_fields = {}
        choices = dict(bytesize=['5','6','7','8'], parity=['N','E','O','M','S'],
                       stopbits=['1','1.5','2'], flow_control=['none','rtscts','dsrdtr','xonxoff'])
        labels = dict(bytesize='数据位', parity='校验位', stopbits='停止位', flow_control='流控')
        for key, values in choices.items():
            field = QComboBox(); field.addItems(values); field.setCurrentText(options[key])
            self.serial_fields[key] = field; form.addRow(labels[key], field)
        layout.addWidget(serial)
        ssh = QGroupBox('SSH 私钥（密码和私钥口令不保存）')
        form = QFormLayout(ssh)
        self.private_key = QLineEdit(options['private_key'])
        choose = QPushButton('选择私钥文件')
        choose.clicked.connect(self.choose_key)
        self.passphrase = QLineEdit(); self.passphrase.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow('私钥路径', self.private_key); form.addRow('', choose)
        form.addRow('本次私钥口令', self.passphrase); layout.addWidget(ssh)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def choose_key(self):
        path, _ = QFileDialog.getOpenFileName(self, '选择私钥')
        if path: self.private_key.setText(path)

    def values(self):
        return dict(encoding=self.encoding.currentText(), backspace=self.backspace.currentText(),
                    private_key=self.private_key.text().strip(),
                    **{k:v.currentText() for k,v in self.serial_fields.items()})


class Window(QMainWindow):
    def __init__(self, *, profile_path=None):
        super().__init__()
        self.setWindowTitle('Harbor Terminal · SSH / Serial')
        self.resize(1280, 820)
        self.workers = []
        self.sessions = {}
        self._closing_tabs = set()
        self._closing = False
        self._probe = None
        self.service_panels = {}
        self.options = dict(DEFAULTS)
        self.passphrase = None
        self.profile_path = Path(profile_path) if profile_path else Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppConfigLocation)) / 'HarborTerminal' / 'sessions.json'
        self.profiles = {}
        self.profile_error = None
        try:
            self.profiles = profiles.load(self.profile_path)
        except (OSError, ValueError, TypeError) as exc:
            self.profile_error = type(exc).__name__
        self.setStyleSheet('''QMainWindow,QWidget {background:#14202c;color:#d7e5ef;}
            QLineEdit,QComboBox,QTreeWidget {background:#1c2d3e;border:1px solid #3c5369;border-radius:4px;padding:5px;}
            QPushButton {background:#243e53;border:1px solid #46647c;border-radius:4px;padding:7px 12px;}
            QPushButton:hover {background:#31566d;} QPushButton:disabled {color:#718799;}
            QTabBar::tab {padding:9px;background:#1c2d3e;} QTabBar::tab:selected {background:#31516a;}
            QGroupBox {border:1px solid #3c5369;margin-top:10px;padding-top:12px;}''')
        root = QWidget(); layout = QVBoxLayout(root); self.setCentralWidget(root)
        title = QLabel('HARBOR  /  SSH · SERIAL'); title.setStyleSheet('color:#78d8c2;font-weight:bold;font-size:18px;padding:6px;')
        layout.addWidget(title)
        row = QHBoxLayout(); layout.addLayout(row)
        self.mode = QComboBox(); self.mode.addItems(['SSH', 'Serial'])
        self.host = QLineEdit(); self.host.setPlaceholderText('主机名 / COM3 / /dev/ttyUSB0')
        self.port = QLineEdit('22'); self.port.setMaximumWidth(100)
        self.user = QLineEdit(); self.user.setPlaceholderText('用户名')
        self.password = QLineEdit(); self.password.setPlaceholderText('本次密码 / 留空使用密钥')
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        for widget in (self.mode,self.host,self.port,self.user,self.password): row.addWidget(widget)
        row = QHBoxLayout(); layout.addLayout(row)
        self.known = QLineEdit(); self.known.setPlaceholderText('known_hosts 路径；默认 ~/.ssh/known_hosts，需先独立核验指纹')
        browse = QPushButton('选择 known_hosts'); browse.clicked.connect(self.choose_known_hosts)
        self.settings_button = QPushButton('连接设置'); self.settings_button.clicked.connect(self.edit_options)
        row.addWidget(self.known); row.addWidget(browse); row.addWidget(self.settings_button)
        self.serial_row = QWidget(); row = QHBoxLayout(self.serial_row); row.setContentsMargins(0,0,0,0)
        self.devices = QComboBox(); self.devices.addItem('选择可用串口，或在上方手动输入', '')
        self.refresh_ports = QPushButton('刷新设备'); self.refresh_ports.clicked.connect(self.scan_ports)
        self.devices.activated.connect(self.pick_port)
        row.addWidget(self.devices,1); row.addWidget(self.refresh_ports)
        layout.addWidget(self.serial_row); self.serial_row.hide()
        row = QHBoxLayout(); layout.addLayout(row)
        self.connect_button = QPushButton('连接'); self.connect_button.clicked.connect(self.connect_session)
        disconnect = QPushButton('断开当前'); disconnect.clicked.connect(self.disconnect)
        self.break_button = QPushButton('发送 BREAK'); self.break_button.clicked.connect(self.send_break)
        save = QPushButton('保存会话'); save.clicked.connect(self.save_profile)
        self.saved = QComboBox(); self.saved.textActivated.connect(self.load_profile)
        for widget in (self.connect_button,disconnect,self.break_button,save,self.saved): row.addWidget(widget)
        services = QHBoxLayout(); layout.addLayout(services)
        self.sftp_button = QPushButton('SFTP 文件'); self.sftp_button.clicked.connect(self.open_sftp)
        self.log_button = QPushButton('会话日志'); self.log_button.clicked.connect(self.open_log)
        self.hex_button = QPushButton('串口 Hex'); self.hex_button.clicked.connect(self.open_hex)
        self.activity = QLabel(); self.activity.setTextFormat(Qt.TextFormat.PlainText)
        for widget in (self.sftp_button, self.log_button, self.hex_button): services.addWidget(widget)
        services.addWidget(self.activity, 1)
        search_row = QHBoxLayout(); layout.addLayout(search_row)
        self.search = QLineEdit(); self.search.setPlaceholderText('当前终端查找 / 高亮（字面文本）')
        self.search.returnPressed.connect(self.find_next)
        self.find_shortcut = QShortcut(QKeySequence.StandardKey.Find,self)
        self.find_shortcut.activated.connect(self.search.setFocus)
        prev = QPushButton('上一处'); prev.clicked.connect(lambda: self.find_next(True))
        next_button = QPushButton('下一处'); next_button.clicked.connect(self.find_next)
        search_row.addWidget(self.search,1); search_row.addWidget(prev); search_row.addWidget(next_button)
        self.status = QLabel('就绪 · 严格校验主机密钥 · Ctrl+Shift+C/V 复制粘贴 · Ctrl+滚轮缩放')
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        self.tabs = QTabWidget(); self.tabs.setTabsClosable(True); self.tabs.setMovable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab); self.tabs.currentChanged.connect(self.current_changed)
        layout.addWidget(self.tabs,1)
        self._build_manager()
        self.update_profiles()
        self.close_timer = QTimer(self); self.close_timer.timeout.connect(self.finish_close)
        self.service_timer = QTimer(self); self.service_timer.setInterval(200)
        self.service_timer.timeout.connect(self.update_activity); self.service_timer.start()
        self.mode.currentTextChanged.connect(self.mode_changed)
        if self.profile_error:
            self.status.setText('会话文件无法读取，已禁用保存以保护原文件：'+self.profile_error)

    def _build_manager(self):
        dock = QDockWidget('会话管理', self)
        panel = QWidget(); layout = QVBoxLayout(panel)
        self.session_filter = QLineEdit(); self.session_filter.setPlaceholderText('筛选名称 / 主机 / 用户')
        self.session_filter.textChanged.connect(self.update_profiles)
        self.tree = QTreeWidget(); self.tree.setHeaderHidden(True)
        self.tree.itemDoubleClicked.connect(self.connect_profile)
        layout.addWidget(self.session_filter); layout.addWidget(self.tree)
        dock.setWidget(panel); self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea,dock)

    def update_profiles(self, *_):
        self.saved.clear(); self.saved.addItem('选择已保存会话'); self.saved.addItems(sorted(self.profiles))
        self.tree.clear(); folders = {}
        query = self.session_filter.text().casefold()
        for name,profile in sorted(self.profiles.items()):
            if query and query not in (' '.join((name,profile.get('host',''),profile.get('username','')))).casefold():
                continue
            parts = name.split('/'); parent = None
            for i,part in enumerate(parts[:-1]):
                key = '/'.join(parts[:i+1])
                if key not in folders:
                    item = QTreeWidgetItem([part]); folders[key] = item
                    (parent.addChild(item) if parent else self.tree.addTopLevelItem(item))
                parent = folders[key]
            item = QTreeWidgetItem([parts[-1]])
            item.setData(0,Qt.ItemDataRole.UserRole,name)
            item.setToolTip(0,f"{profile.get('mode','SSH')} · {profile.get('host','')}")
            (parent.addChild(item) if parent else self.tree.addTopLevelItem(item))
        self.tree.expandAll()

    def connect_profile(self, item, _column):
        name = item.data(0,Qt.ItemDataRole.UserRole)
        if name: self.load_profile(name); self.connect_session()

    def mode_changed(self, mode):
        serial = mode == 'Serial'
        self.port.setText('115200' if serial else '22')
        self.serial_row.setVisible(serial)
        self.user.setEnabled(not serial); self.password.setEnabled(not serial)
        self.known.setEnabled(not serial)
        if serial: self.scan_ports()

    def scan_ports(self):
        if self._probe and self._probe.isRunning(): return
        self.refresh_ports.setEnabled(False)
        probe = PortProbe(); self._probe = probe
        probe.ports_ready.connect(self.ports_ready)
        probe.failed.connect(self.status.setText)
        probe.finished.connect(self.port_probe_finished)
        probe.start()

    @Slot()
    def port_probe_finished(self):
        if self.sender() is self._probe:
            self.refresh_ports.setEnabled(True)

    @Slot(list)
    def ports_ready(self, ports):
        self.devices.clear(); self.devices.addItem('选择串口，或手动输入设备名','')
        for port in ports:
            self.devices.addItem(f"{port['device']} · {port['description']}",port['device'])
            self.devices.setItemData(self.devices.count()-1,port['hwid'],Qt.ItemDataRole.ToolTipRole)
        if not ports: self.status.setText('未发现串口，仍可手动填写设备路径。云端不能看到本机 Windows COM。')

    def pick_port(self, index):
        device = self.devices.itemData(index)
        if device: self.host.setText(device)

    def choose_known_hosts(self):
        path,_ = QFileDialog.getOpenFileName(self,'选择已核验的 known_hosts')
        if path: self.known.setText(path)

    def edit_options(self):
        dialog = ConnectionOptions(self.options,self)
        try:
            if dialog.exec() == QDialog.DialogCode.Accepted:
                self.options = dialog.values(); self.passphrase = dialog.passphrase.text() or None
        finally:
            dialog.passphrase.clear()
            dialog.deleteLater()

    def load_profile(self, name):
        profile = self.profiles.get(name)
        if not profile: return
        self.mode.setCurrentText(profile.get('mode','SSH'))
        for widget,key in ((self.host,'host'),(self.port,'port'),(self.user,'username'),(self.known,'known_hosts')):
            widget.setText(profile.get(key,''))
        self.options = {key:profile.get(key,value) for key,value in DEFAULTS.items()}
        self.password.clear(); self.passphrase = None

    def save_profile(self):
        if self.profile_error:
            self.status.setText('请先备份并修复损坏的会话文件'); return
        name,ok = QInputDialog.getText(self,'保存会话','名称，支持 文件夹/会话')
        if not ok or not name.strip(): return
        name = name.strip()
        if name in self.profiles and QMessageBox.question(self,'替换会话','覆盖同名会话？') != QMessageBox.StandardButton.Yes:
            return
        updated = dict(self.profiles)
        updated[name] = dict(mode=self.mode.currentText(),host=self.host.text().strip(),port=self.port.text(),
                             username=self.user.text().strip(),known_hosts=self.known.text().strip(),**self.options)
        try:
            profiles.save(self.profile_path,updated)
        except (OSError,ValueError):
            self.status.setText('保存失败，请检查会话参数；原文件已保留'); return
        self.profiles = updated; self.update_profiles()
        self.status.setText('会话已保存，密码和私钥口令不写入磁盘')

    def connect_session(self):
        if self._closing or self.tabs.count() >= 16:
            self.status.setText('最多打开 16 个会话，请关闭旧标签'); return
        try:
            number = int(self.port.text())
            if self.options['encoding'] not in ENCODINGS: raise ValueError('encoding')
            if self.mode.currentText() == 'Serial':
                settings = SerialSettings(number,int(self.options['bytesize']),self.options['parity'],
                                          float(self.options['stopbits']),self.options['flow_control'])
                options = dict(device=self.host.text().strip(),baudrate=settings.baudrate,
                               bytesize=settings.bytesize,parity=settings.parity,
                               stopbits=settings.stopbits,flow_control=settings.flow_control)
            else:
                if not 1 <= number <= 65535: raise ValueError('port')
                options = dict(host=self.host.text().strip(),username=self.user.text().strip(),
                               port=number,password=self.password.text() or None,
                               passphrase=self.passphrase,known_hosts=self.known.text().strip() or None)
                if self.options['private_key']: options['client_keys'] = [self.options['private_key']]
        except (ValueError,TypeError):
            self.status.setText('连接参数无效，请检查端口、编码或串口设置'); return
        self.password.clear(); self.passphrase = None
        worker = Worker(self.mode.currentText(),options)
        terminal = Terminal(worker,encoding=self.options['encoding'],backspace=self.options['backspace'])
        terminal.session_label = self.host.text().strip()[:40] or '会话'
        self.sessions[worker] = terminal; self.workers.append(worker)
        self.tabs.setCurrentIndex(self.tabs.addTab(terminal,terminal.session_label))
        worker.state.connect(self.on_worker_state)
        worker.failed.connect(self.on_worker_error)
        worker.finished.connect(self.on_worker_finished)
        worker.file_result.connect(self.on_file_result)
        worker.start(); terminal.setFocus()

    @Slot(str)
    def on_worker_state(self, state):
        self.session_state(self.sender(), state)

    @Slot(str)
    def on_worker_error(self, message):
        self.session_error(self.sender(), message)

    @Slot()
    def on_worker_finished(self):
        self.worker_finished(self.sender())

    @Slot(dict)
    def on_file_result(self, event):
        terminal = self.sessions.get(self.sender())
        if terminal and (event['status'] in ('error', 'uncertain') or event.get('cleanup_warning')):
            terminal.last_file_error = event.get('message', '临时文件或SFTP通道清理未确认，请检查')
            if self.tabs.currentWidget() is terminal:
                self.status.setText(terminal.last_file_error)

    def service_panel(self, kind):
        terminal = self.tabs.currentWidget()
        if not terminal:
            self.status.setText('请先选择会话'); return None
        worker = terminal.worker
        if kind == 'sftp' and worker.mode != 'SSH':
            self.status.setText('SFTP 仅用于当前SSH会话'); return None
        if kind == 'hex' and worker.mode != 'Serial':
            self.status.setText('当前Hex视图用于串口原始字节'); return None
        key = (worker, kind)
        if key not in self.service_panels:
            if kind == 'sftp':
                panel = SFTPDialog(worker, terminal.session_label, self)
            elif kind == 'hex':
                panel = HexDialog(worker, terminal.session_label, self)
            else:
                panel = LogDialog(worker, terminal.session_label, terminal.encoding, self)
            self.service_panels[key] = panel
        panel = self.service_panels[key]
        panel.show(); panel.raise_(); panel.activateWindow()
        return panel

    def open_sftp(self):
        panel = self.service_panel('sftp')
        if panel and not panel.pending:
            panel.refresh_directory()

    def open_log(self):
        self.service_panel('log')

    def open_hex(self):
        self.service_panel('hex')

    def update_activity(self):
        terminal = self.tabs.currentWidget()
        if not terminal:
            self.activity.clear(); return
        worker = terminal.worker
        notes = []
        if worker.journal:
            value = worker.journal.snapshot()
            notes.append('日志：' + (value['error'] or ('暂停' if value['paused'] and value['alive'] else value['state'])))
        progress = worker.file_progress()
        if progress.get('phase') in ('starting','transferring','verifying','committing'):
            notes.append('SFTP：' + progress['phase'])
        self.activity.setText(' · '.join(notes))

    def session_state(self, worker, state):
        terminal = self.sessions.get(worker)
        if not terminal: return
        index = self.tabs.indexOf(terminal)
        if index >= 0:
            self.tabs.setTabText(index,terminal.session_label+' · '+STATES.get(state,state))
            self.tabs.tabBar().setTabTextColor(index,QColor('#78d8c2' if state=='Connected' else '#a3b7c9'))
        if self.tabs.currentWidget() is terminal:
            self.status.setText(terminal.session_label+' · '+STATES.get(state,state))

    def session_error(self, worker, message):
        terminal = self.sessions.get(worker)
        if terminal:
            terminal.connection_error = message
            index = self.tabs.indexOf(terminal)
            if index >= 0: self.tabs.setTabToolTip(index,message)
            if self.tabs.currentWidget() is terminal:
                self.status.setText(terminal.session_label+' · '+message)

    def current_changed(self, _):
        terminal = self.tabs.currentWidget()
        if terminal:
            self.status.setText(terminal.session_label+' · '+getattr(terminal,'connection_error',STATES.get(terminal.worker.status,terminal.worker.status)))
            terminal.setFocus()

    def disconnect(self):
        terminal = self.tabs.currentWidget()
        if terminal: terminal.worker.stop_event.set()

    def send_break(self):
        terminal = self.tabs.currentWidget()
        if terminal and not terminal.worker.send_break(): self.status.setText('当前会话未连接，无法发送 BREAK')

    def find_next(self, backwards=False):
        terminal = self.tabs.currentWidget()
        if terminal and not terminal.find(self.search.text(),backwards=bool(backwards)):
            self.status.setText('当前终端未找到匹配；查找按字面文本进行')

    def close_tab(self, index):
        terminal = self.tabs.widget(index)
        if not terminal: return
        worker = terminal.worker
        if worker.isRunning():
            self._closing_tabs.add(worker); worker.stop_event.set()
            return
        self.remove_session(worker)

    def remove_session(self, worker):
        terminal = self.sessions.pop(worker,None)
        if terminal:
            for key in [key for key in self.service_panels if key[0] is worker]:
                panel = self.service_panels.pop(key)
                panel.close(); panel.deleteLater()
            self.tabs.removeTab(self.tabs.indexOf(terminal)); terminal.timer.stop()
            terminal.deleteLater(); self.workers.remove(worker)
            self._closing_tabs.discard(worker); worker.deleteLater()

    def worker_finished(self, worker):
        terminal = self.sessions.get(worker)
        if terminal and getattr(terminal,'connection_error',None):
            self.current_changed(self.tabs.currentIndex())
        if worker in self._closing_tabs: self.remove_session(worker)

    def finish_close(self):
        busy = any(w.isRunning() for w in self.workers) or (self._probe and self._probe.isRunning())
        if not busy:
            self.close_timer.stop(); self.close()

    def closeEvent(self, event):
        self._closing = True; self.connect_button.setEnabled(False)
        for worker in self.workers: worker.stop_event.set()
        busy = any(w.isRunning() for w in self.workers) or (self._probe and self._probe.isRunning())
        if busy:
            self.status.setText('正在取消任务并关闭连接…'); self.close_timer.start(50)
            event.ignore(); return
        for terminal in self.sessions.values(): terminal.timer.stop()
        for panel in self.service_panels.values(): panel.close()
        self.service_timer.stop()
        self.password.clear(); self.passphrase = None
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = Window(); window.show()
    sys.exit(app.exec())


if __name__ == '__main__': main()
