"""One cancellable owner per connection; reads and writes have independent tasks."""
import asyncio
from collections import deque
import threading

import asyncssh
import serial

from PySide6.QtCore import QThread, Signal

from .serial_config import discover_ports
from .transport import SSHTransport, SerialTransport


class Worker(QThread):
    failed = Signal(str)
    state = Signal(str)

    def __init__(self, mode, options, *, transport_factory=None):
        super().__init__()
        self.mode, self.options = mode, dict(options)
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.incoming, self.outgoing = bytearray(), bytearray()
        self.status = 'Disconnected'
        self._size = (100, 30)
        self._resize = True
        self._controls = deque(maxlen=16)
        self._factory = transport_factory or (SSHTransport if mode == 'SSH' else SerialTransport)

    def _set_state(self, state):
        self.status = state
        self.state.emit(state)

    def send(self, data):
        with self.lock:
            if self.status != 'Connected' or self.stop_event.is_set():
                return False
            if len(self.outgoing) + len(data) > 65536:
                return False
            self.outgoing.extend(data)
        return True

    def resize(self, columns, rows):
        with self.lock:
            self._size = (max(1, min(512, columns)), max(1, min(200, rows)))
            self._resize = True

    def send_break(self):
        with self.lock:
            if self.status != 'Connected' or self.stop_event.is_set() or len(self._controls) >= 16:
                return False
            self._controls.append(('break', 0.25))
        return True

    def take(self):
        with self.lock:
            result = bytes(self.incoming[:16384])
            del self.incoming[:16384]
        return result

    async def _wait_stop(self):
        while not self.stop_event.is_set():
            await asyncio.sleep(.01)

    async def _reader(self, transport):
        while True:
            data = await transport.read()
            if not data and self.mode == 'SSH':
                return
            while data:
                with self.lock:
                    available = 262144 - len(self.incoming)
                    self.incoming.extend(data[:available])
                data = data[available:]
                if data:
                    await asyncio.sleep(.01)

    async def _writer(self, transport):
        while True:
            with self.lock:
                if self.stop_event.is_set():
                    self.outgoing.clear()
                    return
                outgoing = bytes(self.outgoing)
                self.outgoing.clear()
            if outgoing:
                await asyncio.wait_for(transport.write(outgoing), 5)
            else:
                await asyncio.sleep(.01)

    async def _control(self, transport):
        while True:
            with self.lock:
                if self.stop_event.is_set():
                    self._controls.clear()
                    return
                size = self._size if self._resize else None
                self._resize = False
                control = self._controls.popleft() if self._controls else None
            if size and self.mode == 'SSH':
                await transport.resize(*size)
            if control:
                await asyncio.wait_for(transport.send_break(control[1]), 3)
            await asyncio.sleep(.025)

    async def session(self):
        transport = self._factory()
        tasks = []
        try:
            if self.stop_event.is_set():
                return
            self._set_state('Connecting')
            options = dict(self.options)
            if self.mode == 'SSH':
                with self.lock:
                    options['term_size'] = self._size
            connect = asyncio.create_task(transport.connect(**options))
            stop = asyncio.create_task(self._wait_stop())
            tasks.extend((connect, stop))
            done, _ = await asyncio.wait((connect, stop), return_when=asyncio.FIRST_COMPLETED)
            if stop in done:
                return
            await connect
            options.clear()
            self.options.pop('password', None)
            self.options.pop('passphrase', None)
            self._set_state('Connected')
            running = [asyncio.create_task(operation(transport)) for operation in
                       (self._reader, self._writer, self._control)]
            tasks.extend(running)
            done, _ = await asyncio.wait([*running, stop], return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                await task
        except Exception as exc:
            # Type is diagnostic; arbitrary exception text may contain secrets.
            if isinstance(exc, asyncssh.HostKeyNotVerifiable):
                message = '主机密钥未知或已变更，请独立核验；不会跳过校验'
            elif isinstance(exc, asyncssh.PermissionDenied):
                message = '认证被拒绝，请检查用户名、密码或密钥'
            elif isinstance(exc, serial.SerialException):
                message = '串口不可用、已被占用或设备已断开'
            elif isinstance(exc, TimeoutError):
                message = '连接或写入超时，已停止会话'
            else:
                message = '连接失败，请检查主机信任、认证或设备权限'
            self.failed.emit(type(exc).__name__ + ': ' + message)
        finally:
            self._set_state('Closing')
            for task in tasks:
                task.cancel()
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
            self.options.pop('password', None)
            self.options.pop('passphrase', None)
            with self.lock:
                self.outgoing.clear()
                self._controls.clear()
            try:
                await transport.close()
            except Exception:
                self.failed.emit('Connection cleanup failed')
            self._set_state('Disconnected')

    def run(self):
        asyncio.run(self.session())


class PortProbe(QThread):
    ports_ready = Signal(list)
    failed = Signal(str)

    def run(self):
        try:
            self.ports_ready.emit(discover_ports())
        except Exception:
            self.failed.emit('无法枚举串口；仍可手动输入设备名')
