"""Qt UI: network I/O lives on a worker, bounded queues enforce backpressure."""
import asyncio
import codecs
import sys
import threading
from pathlib import Path
import pyte
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QStandardPaths
from PySide6.QtGui import QFont, QTextCursor, QKeySequence
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLineEdit, QComboBox, QPushButton, QPlainTextEdit, QLabel, QTabWidget, QMessageBox, QInputDialog, QMenu)
from .transport import SSHTransport, SerialTransport
from . import profiles
from .terminal_stream import SafeTerminalStream


class Worker(QThread):
    failed = Signal(str)
    state = Signal(str)

    def __init__(self, mode, options):
        super().__init__()
        self.mode, self.options = mode, options
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.incoming, self.outgoing = bytearray(), bytearray()

    def send(self, data):
        with self.lock:
            if len(self.outgoing) + len(data) > 65536:
                return False
            self.outgoing.extend(data)
        return True

    def take(self):
        with self.lock:
            result = bytes(self.incoming[:16384])
            del self.incoming[:16384]
        return result

    async def session(self):
        transport = SSHTransport() if self.mode == 'SSH' else SerialTransport()
        try:
            self.state.emit('Connecting')
            await transport.connect(**self.options)
            self.options.pop('password', None)
            self.state.emit('Connected')
            read_task = asyncio.create_task(transport.read())
            try:
                while not self.stop_event.is_set():
                    if read_task.done():
                        data = read_task.result()
                        if not data and self.mode == 'SSH':
                            break
                        while data and not self.stop_event.is_set():
                            with self.lock:
                                available = 262144 - len(self.incoming)
                                self.incoming.extend(data[:available])
                            data = data[available:]
                            if data:
                                await asyncio.sleep(.01)
                        read_task = asyncio.create_task(transport.read())
                    with self.lock:
                        outgoing = bytes(self.outgoing)
                        self.outgoing.clear()
                    if outgoing:
                        await asyncio.wait_for(transport.write(outgoing), 5)
                    await asyncio.sleep(.01)
            finally:
                read_task.cancel()
                await asyncio.gather(read_task, return_exceptions=True)
        except Exception as exc:
            # Never include connection options or password in errors/logs.
            self.failed.emit(type(exc).__name__ + ': connection failed; check host trust, credentials and device access')
        finally:
            self.options.pop('password', None)
            try:
                await transport.close()
            except Exception:
                self.failed.emit('Connection cleanup failed')
            self.state.emit('Disconnected')

    def run(self):
        asyncio.run(self.session())


class Terminal(QPlainTextEdit):
    def __init__(self, worker):
        super().__init__()
        self.worker = worker
        self.setReadOnly(True)
        self.setFont(QFont('monospace', 11))
        self.setStyleSheet('background:#101923;color:#d3e3ee;')
        self.screen = pyte.HistoryScreen(100, 30, history=2000)
        self.stream = SafeTerminalStream(self.screen)
        self.decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(30)

    def refresh(self):
        data = self.worker.take()
        if data:
            try:
                self.stream.feed(self.decoder.decode(data))
            except Exception:
                self.worker.stop_event.set()
                self.timer.stop()
                self.setPlainText('终端解析失败，已停止会话以避免继续处理异常数据。')
                return
            history = [''.join(line[x].data for x in range(100)) for line in self.screen.history.top]
            self.setPlainText('\n'.join(history + self.screen.display))
            cursor = self.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.Start)
            cursor.movePosition(QTextCursor.MoveOperation.Down, n=len(history) + self.screen.cursor.y)
            cursor.movePosition(QTextCursor.MoveOperation.Right, n=self.screen.cursor.x)
            self.setTextCursor(cursor)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.StandardKey.Paste):
            self.paste_confirmed()
            return
        if event.matches(QKeySequence.StandardKey.Copy):
            self.copy()
            return
        keys = {Qt.Key.Key_Return:b'\r', Qt.Key.Key_Enter:b'\r', Qt.Key.Key_Backspace:b'\x7f',
                Qt.Key.Key_Up:b'\x1b[A', Qt.Key.Key_Down:b'\x1b[B',
                Qt.Key.Key_Right:b'\x1b[C', Qt.Key.Key_Left:b'\x1b[D', Qt.Key.Key_Tab:b'\t',
                Qt.Key.Key_Escape:b'\x1b'}
        data = keys.get(event.key(), event.text().encode('utf-8'))
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier and Qt.Key.Key_A <= event.key() <= Qt.Key.Key_Z:
            data = bytes([event.key() - Qt.Key.Key_A + 1])
        if data and not self.worker.send(data):
            QApplication.beep()

    def paste_confirmed(self):
        text = QApplication.clipboard().text()
        data = text.encode('utf-8')
        if len(data) > 65536:
            QMessageBox.warning(self, '粘贴过大', '最多粘贴 64 KiB')
            return
        if any(ord(char) < 32 and char not in '\r\n\t' for char in text):
            QMessageBox.warning(self, '拒绝控制字符', '剪贴板包含终端控制字符')
            return
        if '\n' in text or '\r' in text:
            if QMessageBox.question(self, '确认多行粘贴', '多行粘贴可能立即执行命令，是否继续？') != QMessageBox.StandardButton.Yes:
                return
        if data and not self.worker.send(data):
            QApplication.beep()

    def contextMenuEvent(self, event):
        # The standard text menu bypasses the remote-terminal paste guard.
        menu = QMenu(self)
        menu.addAction('复制', self.copy)
        menu.addAction('粘贴（检查）', self.paste_confirmed)
        menu.exec(event.globalPos())


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Harbor Terminal · SSH / Serial')
        self.resize(1120, 760)
        self.workers = []
        self.profile_path = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppConfigLocation)) / 'HarborTerminal' / 'sessions.json'
        self.profiles = {}
        self.profile_error = None
        try:
            self.profiles = profiles.load(self.profile_path)
        except (OSError, ValueError, TypeError) as exc:
            self.profile_error = type(exc).__name__
        root = QWidget(); layout = QVBoxLayout(root); self.setCentralWidget(root)
        layout.addWidget(QLabel('Harbor Terminal  |  严格校验主机密钥 · 密码不保存 · 串口 8N1'))
        row = QHBoxLayout(); layout.addLayout(row)
        self.mode = QComboBox(); self.mode.addItems(['SSH', 'Serial'])
        self.host = QLineEdit(); self.host.setPlaceholderText('SSH 主机 / 串口设备，例如 COM3')
        self.port = QLineEdit('22'); self.port.setMaximumWidth(90)
        self.user = QLineEdit(); self.user.setPlaceholderText('用户名')
        self.password = QLineEdit(); self.password.setPlaceholderText('密码（留空使用密钥/agent）')
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.known = QLineEdit(); self.known.setPlaceholderText('known_hosts 文件，留空使用 ~/.ssh/known_hosts')
        for widget in (self.mode, self.host, self.port, self.user, self.password): row.addWidget(widget)
        layout.addWidget(self.known)
        buttons = QHBoxLayout(); layout.addLayout(buttons)
        connect = QPushButton('连接'); disconnect = QPushButton('断开当前会话')
        buttons.addWidget(connect); buttons.addWidget(disconnect)
        self.saved = QComboBox(); self.saved.addItem('选择已保存会话'); self.saved.addItems(sorted(self.profiles))
        save_button = QPushButton('保存会话（不含密码）')
        buttons.addWidget(self.saved); buttons.addWidget(save_button)
        self.saved.textActivated.connect(self.load_profile)
        save_button.clicked.connect(self.save_profile)
        self.status = QLabel('就绪：首次连接前请独立核验 SSH 指纹'); layout.addWidget(self.status)
        self.tabs = QTabWidget(); self.tabs.setTabsClosable(True); layout.addWidget(self.tabs)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        if self.profile_error:
            self.status.setText('会话文件无法读取；为保护原文件，已禁用保存：' + self.profile_error)
        connect.clicked.connect(self.connect_session); disconnect.clicked.connect(self.disconnect)
        self.mode.currentTextChanged.connect(lambda value: self.port.setText('22' if value == 'SSH' else '115200'))

    def load_profile(self, name):
        profile = self.profiles.get(name)
        if profile:
            self.mode.setCurrentText(profile.get('mode', 'SSH'))
            for widget, key in ((self.host, 'host'), (self.port, 'port'),
                                (self.user, 'username'), (self.known, 'known_hosts')):
                widget.setText(profile.get(key, ''))
            self.password.clear()

    def save_profile(self):
        if self.profile_error:
            self.status.setText('请先备份并修复损坏的会话文件')
            return
        name, ok = QInputDialog.getText(self, '保存会话', '会话名称')
        if not ok or not name.strip():
            return
        name = name.strip()
        if name in self.profiles and QMessageBox.question(self, '替换会话', '覆盖同名会话？') != QMessageBox.StandardButton.Yes:
            return
        updated = dict(self.profiles)
        updated[name] = dict(mode=self.mode.currentText(), host=self.host.text(), port=self.port.text(),
                             username=self.user.text(), known_hosts=self.known.text())
        try:
            profiles.save(self.profile_path, updated)
        except (OSError, ValueError):
            self.status.setText('保存失败，原会话文件已保留')
            return
        self.profiles = updated
        self.saved.clear(); self.saved.addItem('选择已保存会话'); self.saved.addItems(sorted(updated))
        self.status.setText('会话已保存，密码不写入磁盘')

    def connect_session(self):
        if self.tabs.count() >= 16:
            self.status.setText('最多打开 16 个会话，请先关闭旧标签'); return
        try:
            number = int(self.port.text())
        except ValueError:
            self.status.setText('端口或波特率必须为整数'); return
        if self.mode.currentText() == 'SSH':
            options = dict(host=self.host.text().strip(), username=self.user.text().strip(),
                port=number, password=self.password.text() or None, known_hosts=self.known.text().strip() or None)
        else:
            options = dict(device=self.host.text().strip(), baudrate=number)
        self.password.clear()
        worker = Worker(self.mode.currentText(), options)
        terminal = Terminal(worker)
        self.tabs.setCurrentIndex(self.tabs.addTab(terminal, self.host.text()))
        worker.state.connect(lambda state: self.status.setText(state))
        worker.failed.connect(self.status.setText)
        self.workers.append(worker)
        worker.start()

    def disconnect(self):
        terminal = self.tabs.currentWidget()
        if terminal: terminal.worker.stop_event.set()

    def close_tab(self, index):
        terminal = self.tabs.widget(index)
        worker = terminal.worker
        if worker.isRunning():
            worker.stop_event.set()
            self.status.setText('正在断开，请稍后关闭标签')
            return
        self.tabs.removeTab(index)
        self.workers.remove(worker)
        terminal.deleteLater()
        worker.deleteLater()

    def closeEvent(self, event):
        for worker in self.workers: worker.stop_event.set()
        if any(worker.isRunning() for worker in self.workers):
            self.status.setText('正在安全关闭连接，请稍后再关闭窗口')
            event.ignore()
            return
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = Window(); window.show()
    sys.exit(app.exec())


if __name__ == '__main__': main()
