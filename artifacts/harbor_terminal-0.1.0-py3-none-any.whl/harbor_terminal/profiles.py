"""Versioned atomic session storage. Credentials are never accepted or persisted."""
import json
import os
from pathlib import Path
import tempfile

FIELDS = frozenset(('mode', 'host', 'port', 'username', 'known_hosts'))


def load(path):
    path = Path(path)
    if not path.exists():
        return {}
    if path.stat().st_size > 1048576:
        raise ValueError('Session file exceeds 1 MiB')
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('version') != 1 or not isinstance(data.get('sessions'), dict):
        raise ValueError('Unsupported session file')
    result = data['sessions']
    if len(result) > 500:
        raise ValueError('Too many saved sessions')
    for name, profile in result.items():
        if not isinstance(name, str) or not isinstance(profile, dict):
            raise ValueError('Invalid session entry')
        if set(profile) - FIELDS or any(not isinstance(value, str) for value in profile.values()):
            raise ValueError('Unexpected fields in session file')
    return result


def save(path, sessions):
    # Validate exactly the bytes we will persist before touching an existing file.
    if len(sessions) > 500:
        raise ValueError('Too many saved sessions')
    for name, profile in sessions.items():
        if not isinstance(name, str) or not isinstance(profile, dict) or set(profile) - FIELDS:
            raise ValueError('Credentials and unrecognized fields cannot be saved')
        if any(not isinstance(value, str) for value in profile.values()):
            raise ValueError('Invalid session values')
    payload = json.dumps({'version': 1, 'sessions': sessions}, ensure_ascii=False, indent=2)
    if len(payload.encode('utf-8')) > 1048576:
        raise ValueError('Session file exceeds 1 MiB')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix='.sessions-', dir=path.parent)
    try:
        with os.fdopen(handle, 'w', encoding='utf-8') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
