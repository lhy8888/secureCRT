"""Bounded asynchronous transports. Never trust unknown SSH host keys implicitly."""
import asyncio
from pathlib import Path
import asyncssh
import serial


class SSHTransport:
    def __init__(self):
        self.connection = None
        self.process = None

    async def connect(self, host, username, *, port=22, password=None,
                      known_hosts=None, client_keys=None, timeout=15):
        if self.connection is not None:
            raise RuntimeError("Already connected")
        if not host or not username or not 1 <= int(port) <= 65535:
            raise ValueError("Invalid host, username, or port")
        # An explicit file is mandatory; no known_hosts=None escape hatch.
        path = Path(known_hosts) if known_hosts else Path.home() / '.ssh' / 'known_hosts'
        if not path.is_file():
            raise ValueError("Create a known_hosts file using an independently verified host fingerprint first")
        connection = await asyncio.wait_for(asyncssh.connect(
            host, port=int(port), username=username, password=password,
            known_hosts=str(path), client_keys=client_keys,
            connect_timeout=timeout, login_timeout=timeout,
            keepalive_interval=15, keepalive_count_max=3,
            agent_forwarding=False), timeout=timeout)
        try:
            process = await asyncio.wait_for(connection.create_process(
                term_type='xterm-256color', term_size=(100, 30), encoding=None, stderr=asyncssh.STDOUT), timeout)
        except BaseException:
            connection.close()
            await connection.wait_closed()
            raise
        self.connection, self.process = connection, process

    async def read(self):
        return await self.process.stdout.read(16384)

    async def write(self, data):
        self.process.stdin.write(data)
        await self.process.stdin.drain()

    async def close(self):
        connection, self.connection = self.connection, None
        self.process = None
        if connection:
            connection.close()
            await asyncio.wait_for(connection.wait_closed(), 5)


class SerialTransport:
    def __init__(self):
        self.port = None

    async def connect(self, device, baudrate=115200):
        if self.port:
            raise RuntimeError("Already connected")
        if int(baudrate) not in (1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400):
            raise ValueError("Unsupported baud rate")
        # Cancellation must close a port opened by the worker after cancellation.
        task = asyncio.create_task(asyncio.to_thread(serial.Serial, device,
            baudrate=int(baudrate), timeout=0.1, write_timeout=2,
            bytesize=8, parity='N', stopbits=1, xonxoff=False, rtscts=False))
        try:
            self.port = await asyncio.shield(task)
        except asyncio.CancelledError:
            port = await task
            port.close()
            raise

    async def read(self):
        port = self.port
        return await asyncio.to_thread(port.read, min(max(port.in_waiting, 1), 16384))

    async def write(self, data):
        port = self.port
        count = await asyncio.to_thread(port.write, data)
        if count != len(data):
            raise IOError("Incomplete serial write")

    async def close(self):
        port, self.port = self.port, None
        if port:
            await asyncio.to_thread(port.close)
